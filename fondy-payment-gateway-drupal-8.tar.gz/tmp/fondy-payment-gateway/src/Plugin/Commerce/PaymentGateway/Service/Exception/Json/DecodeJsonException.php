<?php

namespace Drupal\commerce_fondy\Plugin\Commerce\PaymentGateway\Service\Exception\Json;

use Exception;

final class DecodeJsonException extends Exception
{
}
