<?php

namespace Drupal\commerce_fondy\Plugin\Commerce\PaymentGateway\Entity;

interface ConfigurationOptionsInterface
{
    /**
     * @return array
     */
    public function getConfigurationOptions();
}
