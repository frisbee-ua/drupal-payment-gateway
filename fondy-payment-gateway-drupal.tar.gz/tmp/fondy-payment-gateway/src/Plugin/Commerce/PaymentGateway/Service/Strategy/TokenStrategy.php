<?php

namespace Drupal\commerce_fondy\Plugin\Commerce\PaymentGateway\Service\Strategy;

final class TokenStrategy extends AbstractStrategy
{
    const NAME = 'token';
}
