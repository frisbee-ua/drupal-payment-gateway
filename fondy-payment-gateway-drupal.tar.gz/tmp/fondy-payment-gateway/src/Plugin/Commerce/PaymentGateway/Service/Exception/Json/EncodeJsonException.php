<?php

namespace Drupal\commerce_fondy\Plugin\Commerce\PaymentGateway\Service\Exception\Json;

use Exception;

final class EncodeJsonException extends Exception
{
}
